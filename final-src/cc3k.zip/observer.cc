#include "observer.h"

void Observer::use(Player &p) {
	return;
}
