#ifndef __SUBSCRIPTIONS_H__
#define __SUBSCRIPTIONS_H__

enum class SubscriptionType { Display, Enemy, Potion, Stairs, Move, Gold, Player, Dragon };

#endif
